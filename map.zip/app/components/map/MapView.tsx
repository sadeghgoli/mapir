'use client';

import dynamic from 'next/dynamic';

// تمام کامپوننت‌های react-leaflet باید به صورت dynamic وارد شوند
const MapContainer = dynamic(
    () => import('react-leaflet').then((mod) => mod.MapContainer),
    { ssr: false }
);

// همچنین برای سایر کامپوننت‌های سفارشی که از react-leaflet استفاده می‌کنند
import BaseTileLayer from './layers/BaseTileLayer';
import HouseMarker from './markers/HouseMarker';

const CENTER: [number, number] = [35.6892, 51.3890];

function MapComponent() {
    return (
        <MapContainer
            center={CENTER}
            zoom={14}
            zoomControl={false}
            className="w-full h-full z-0"
        >
            <BaseTileLayer />
            <HouseMarker />
        </MapContainer>
    );
}

export default dynamic(() => Promise.resolve(MapComponent), {
    ssr: false,
});