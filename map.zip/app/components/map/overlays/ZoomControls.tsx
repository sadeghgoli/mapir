'use client';

import {
    Plus,
    Minus,
    LocateFixed,
} from 'lucide-react';

export default function ZoomControls() {
    return (
        <div
            className="
                absolute
                left-6
                bottom-52
                z-[10]
                flex
                flex-col
                gap-3
            "
        >
            <div className="bg-white rounded-lg w-10 flex items-center justify-center flex-col">
                <button className="h-10 w-10 flex items-center justify-center">
                    <Plus />
                </button>

                <div className="w-full flex items-center justify-center">
                    <div className="h-[1px] w-8 bg-gray-200"></div>
                </div>

                <button className="h-10 w-10 flex items-center justify-center">
                    <Minus />
                </button>
            </div>

            <button className="bg-white h-10 w-10 rounded-lg flex items-center justify-center">
                <LocateFixed />
            </button>
        </div>
    );
}