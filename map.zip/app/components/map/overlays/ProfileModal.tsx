import React, {useEffect, useState} from 'react';
import {X} from "lucide-react";
import PaymentHistoryModal from "./PaymentHistoryMoal";
const ProfileModal = ({ isOpen, onClose, userData }) => {
    const [isModalOpen2, setIsModalOpen2] = useState(false);

    // بستن مودال با دکمه ESC
    useEffect(() => {
        const handleEsc = (e) => {
            if (e.key === 'Escape') {
                onClose();
            }
        };
        if (isOpen) {
            window.addEventListener('keydown', handleEsc);
        }
        return () => {
            window.removeEventListener('keydown', handleEsc);
        };
    }, [isOpen, onClose]);

    // جلوگیری از اسکرول صفحه هنگام باز بودن مودال
    useEffect(() => {
        if (isOpen) {
            document.body.style.overflow = 'hidden';
        } else {
            document.body.style.overflow = 'unset';
        }
        return () => {
            document.body.style.overflow = 'unset';
        };
    }, [isOpen]);

    if (!isOpen) return null;

    const menuItems = [

        {
            id: 'payments',
            title: 'سوابق پرداخت',
            icon: '/images/solar_banknote-2-linear.png',
            onClick: () => {
                setIsModalOpen2(true)
            }
        },
        {
            id: 'locations',
            title: 'مکان های منتخب',
            icon: '/images/solar_star-circle-linear.png',
            onClick: () => {
                console.log('رفتن به مکان‌های منتخب');
                onClose();
            }
        },
        {
            id: 'logout',
            title: 'خروج از حساب کاربری',
            icon: '/images/iconamoon_exit-light.png',
            onClick: () => {
                console.log('خروج از حساب');
                // logout logic here
                onClose();
            },
            isDanger: true // برای استایل قرمز
        }
    ];


    const data = [
        {
            id: '۱',
            trackingCode: '۵۰۱۲۳۵۶۷',
            authCode: 'A9C7F3K2104587',
            billId: '۱۲۳۴۶۷۸۹۰۲۳',
            paymentId: '۹۸۷۶۵۴۳۲۱۰۱۲',
            amount: '۳,۵۰,۰۰۰ ریال',
            date: '۱۴۰۳/۰۶/۱۲',
            time: '۱:۴۵',
            status: 'موفق',
        },
        {
            id: '۲',
            trackingCode: '۵۰۱۲۳۵۶۷',
            authCode: 'A9C7F3K2104587',
            billId: '۲۳۴۵۶۸۹۰۱۲',
            paymentId: '۹۸۷۶۵۴۳۲۱۰۱۲',
            amount: '۳,۵۰۰,۰۰۰ ریال',
            date: '۱۴۰۳/۰۶/۱۲',
            time: '۱۰:۴۵',
            status: 'ناموفق',
        },
        {
            id: '۳',
            trackingCode: '۵۵۰۱۲۳۴۵۶۷',
            authCode: 'A9C7F3K2104587',
            billId: '۱۲۳۴۵۶۷۸۹۰۱۲۳',
            paymentId: '۹۸۷۶۴۳۲۱۰۱۲',
            amount: '۳,۵۰۰,۰۰۰ ریال',
            date: '۱۴۰۳/۰۶/۱۲',
            time: '۱۰:۴۵',
            status: 'موفق',
        },
        {
            id: '۴',
            trackingCode: '۵۵۰۱۲۳۴۵۶۷',
            authCode: 'A9C7F3K2104587',
            billId: '۱۲۳۴۵۶۷۸۹۰۱۲۳',
            paymentId: '۸۷۶۵۴۳۲۱۰۱۲',
            amount: '۳,۵۰,۰۰۰ ریال',
            date: '۱۴۰۳/۰۶/۱',
            time: '۱۰:۴۵',
            status: 'موفق',
        },
        {
            id: '۵',
            trackingCode: '۵۰۱۲۳۴۶۷',
            authCode: 'A9C7F3K2104587',
            billId: '۱۳۴۵۶۷۹۰۱۲۳',
            paymentId: '۹۸۷۶۵۴۳۲۱۰۱۲',
            amount: '۳,۵۰۰,۰۰۰ ریال',
            date: '۱۴۰۳/۰۶/۱۲',
            time: '۱۰:۴۵',
            status: 'موفق',
        },
    ];
    return (
        <>
            {/* بکدراپ تیره */}
            <div
                className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 animate-fadeIn"
                onClick={onClose}
            />

            {/* مودال اصلی */}
            <div className="fixed top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 z-50 w-full max-w-lg animate-slideUp">
                <div className="bg-white rounded-2xl shadow-2xl overflow-hidden">

                    {/* هدر مودال با اطلاعات کاربر */}
                    <div className="bg-[#145d6e] px-5 py-2 text-white flex justify-between items-center w-full">
                       <div class="flex items-center gap-2">
                           <img src="/images/solar_user-circle-bold-duotone2.png" alt=""/>
                           <p class="text-sm">
                               پروفایل کاربری
                           </p>
                       </div>
                        <button
                            onClick={onClose}
                            className="py-2 text-white text-sm font-medium transition-colors"
                        >
                            <X className="w-5 h-5" />
                        </button>
                    </div>

                    {/* منوها */}
                    <div className="py-2" style={{background: '#f9f9f9'}}>
                        <div class="p-3">
                            <div className="flex items-center gap-3 border justify-between rounded-lg border-gray-200 bg-white px-3">

                                <div className="flex justify-center items-center">
                                    <div className="w-16 h-16 rounded-full bg-white/20 flex items-center justify-center">
                                        <img
                                            src="/images/profie-in-modal.png"
                                            alt="avatar"
                                            className="w-12 h-12"
                                        />
                                    </div>
                                    <h3 className="font-bold text-lg">{userData?.name || 'حسن رضایی مقدم'}</h3>
                                </div>
                                <p className="text-lg opacity-90">{userData?.phone || '09123456789'}</p>

                            </div>
                        </div>
                        {menuItems.map((item) => (
                            <button
                                key={item.id}
                                onClick={item.onClick}
                                className={`
                  w-full px-5 py-3 flex items-center gap-3 transition-all duration-200
                  hover:bg-gray-50 active:bg-gray-100
                  ${item.isDanger ? 'text-red-600 hover:bg-red-50' : 'text-gray-700'}
                  border-b
                  border-gray-200
                  last:border-0
                `}
                            >
                                <div className="w-6 h-6 flex items-center justify-center">
                                    <img src={item.icon} alt="" className="w-5 h-5" />
                                </div>
                                <span className="flex-1 text-right font-medium">{item.title}</span>

                            </button>
                        ))}
                    </div>


                </div>
            </div>
            {/* مودال */}
            <PaymentHistoryModal
                isOpen={isModalOpen2}
                onClose={() => setIsModalOpen2(false)}
                data={data}
            />
        </>
    );
};

export default ProfileModal;